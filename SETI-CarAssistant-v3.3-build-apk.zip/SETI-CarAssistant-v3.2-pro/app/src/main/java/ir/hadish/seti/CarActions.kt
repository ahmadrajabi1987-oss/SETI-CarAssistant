package ir.hadish.seti

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.view.KeyEvent

class CarActions(private val a:Activity){
    private fun launch(i:Intent)=try{a.startActivity(i);true}catch(_:Exception){false}
    fun music()=launch(Intent("android.intent.action.MUSIC_PLAYER"))
    fun stopMusic():Boolean=try{val m=a.getSystemService(Activity.AUDIO_SERVICE) as AudioManager;m.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_MEDIA_PAUSE));m.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_MEDIA_PAUSE));true}catch(_:Exception){false}
    fun navigate(raw:String):Boolean{val d=raw.replace(Regex("سلام ستی|سلام seti|ستی|مسیریابی کن|مسیریابی|نقشه|مسیر|ببر به"),"").trim();if(d.isBlank())return false;return launch(Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q=${Uri.encode(d)}")))}
    fun openApp(raw:String):Boolean{val x=raw.lowercase();val p=when{ x.contains("یوتیوب")->"com.google.android.youtube";x.contains("گوگل مپ")->"com.google.android.apps.maps";x.contains("ویز")->"com.waze";else->null}?:return false;return a.packageManager.getLaunchIntentForPackage(p)?.let{launch(it)}?:false}
    fun call(raw:String):String{val name=raw.replace(Regex("سلام ستی|سلام seti|ستی|زنگ بزن|تماس بگیر|تماس|به|با"),"").trim();if(name.isBlank())return "نام مخاطب را بگویید.";if(a.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED||a.checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){a.requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS,Manifest.permission.CALL_PHONE),40);return "برای تماس، اجازه مخاطبین و تلفن لازم است."};a.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),"${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",arrayOf("%$name%"),null)?.use{c->if(c.moveToFirst()){val n=c.getString(0);return try{a.startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:${Uri.encode(n)}")));"در حال تماس با $name"}catch(_:Exception){"تماس برقرار نشد."}}};return "مخاطب $name پیدا نشد."}
}
