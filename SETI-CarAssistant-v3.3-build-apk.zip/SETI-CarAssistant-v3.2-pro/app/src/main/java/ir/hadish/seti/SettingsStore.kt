package ir.hadish.seti
import android.content.Context
class SettingsStore(c:Context){private val p=c.getSharedPreferences("seti",Context.MODE_PRIVATE);var continuous:Boolean get()=p.getBoolean("continuous",false) set(v){p.edit().putBoolean("continuous",v).apply()};var greeting:Boolean get()=p.getBoolean("greeting",true) set(v){p.edit().putBoolean("greeting",v).apply()}}
