package ir.hadish.seti

import java.util.Locale

class CommandRouter {
    fun normalize(s:String)=s.replace('\u200c',' ').replace('ي','ی').replace('ك','ک').replace(Regex("\\s+")," ").trim().lowercase(Locale("fa","IR"))
    fun isWake(s:String):Boolean { val x=normalize(s); return x.contains("سلام ستی") || x.contains("سلام seti") || x=="ستی" || x.startsWith("ستی ") }
    fun clean(s:String)=normalize(s).replace("سلام ستی","").replace("سلام seti","").replace(Regex("^ستی\\s*"),"").trim()
    fun route(raw:String):Command { val x=clean(raw); return when {
        x.isBlank()->Command.Empty
        x.contains("توقف")||x.contains("قطع موسیقی")||x.contains("موسیقی را قطع")||x.contains("آهنگ را قطع")->Command.Stop
        x.contains("موسیقی")||x.contains("آهنگ")||x.contains("پخش کن")||x.contains("پلیر")||x.contains("رادیو")->Command.Play
        x.contains("مسیریابی")||x.contains("نقشه")||x.contains("مسیر")||x.contains("ببر به")||x.contains("من را ببر")||x.contains("منو ببر")->Command.Navigate(raw)
        x.contains("زنگ بزن")||x.contains("تماس بگیر")||x.contains("تماس")->Command.Call(raw)
        x.contains("یوتیوب")||x.contains("گوگل مپ")||x.contains("ویز")->Command.App(raw)
        x.contains("ساعت")||x.contains("چه ساعتی")||x.contains("الان چند")->Command.Time
        x.contains("هوا")||x.contains("آب و هوا")->Command.Weather
        x.contains("کمک")||x.contains("چه کارهایی")||x.contains("فرمان")->Command.Help
        x.contains("سلام")||x.contains("خوبی")||x.contains("چه خبر")->Command.Greet
        x.contains("خداحافظ")||x.contains("فعلا")->Command.Goodbye
        else->Command.Chat(raw)
    }}
}
sealed class Command { data object Empty:Command(); data object Greet:Command(); data object Play:Command(); data object Stop:Command(); data class Navigate(val text:String):Command(); data class Call(val text:String):Command(); data class App(val text:String):Command(); data object Time:Command(); data object Weather:Command(); data object Help:Command(); data object Goodbye:Command(); data class Chat(val text:String):Command() }
