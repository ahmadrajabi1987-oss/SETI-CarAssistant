package ir.hadish.seti

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity:Activity(),TextToSpeech.OnInitListener{
 private lateinit var tts:TextToSpeech;private lateinit var rec:SpeechRecognizer;private lateinit var router:CommandRouter;private lateinit var actions:CarActions;private lateinit var store:SettingsStore
 private lateinit var status:TextView;private lateinit var heard:TextView;private lateinit var connection:TextView
 private val ai=LocalAi(); private lateinit var remoteAi:AiProvider;private val h=Handler(Looper.getMainLooper());private var ready=false;private var listening=false;private var continuous=false
 override fun onCreate(b:Bundle?){super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);setContentView(R.layout.activity_main);status=findViewById(R.id.status);heard=findViewById(R.id.heard);connection=findViewById(R.id.connection);router=CommandRouter();actions=CarActions(this);store=SettingsStore(this);remoteAi=AiProvider(this);continuous=store.continuous;tts=TextToSpeech(this,this);requestAudio();setupRec();findViewById<Button>(R.id.speak).setOnClickListener{continuous=false;listen()};findViewById<Button>(R.id.wake).setOnClickListener{continuous=true;store.continuous=true;say("آماده‌باش SETI فعال شد. بگویید سلام ستی")};findViewById<Button>(R.id.music).setOnClickListener{say(if(actions.music())"موسیقی را باز کردم" else "برنامه موسیقی پیدا نشد")};findViewById<Button>(R.id.map).setOnClickListener{say("مقصد را بگویید");h.postDelayed({listen()},600)};findViewById<Button>(R.id.help).setOnClickListener{say(help())};if(store.greeting)say("سلام، من SETI هستم. آماده‌ام")}
 private fun requestAudio(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10)}
 private fun setupRec(){if(!SpeechRecognizer.isRecognitionAvailable(this)){connection.text="● گفتار در دسترس نیست";return};rec=SpeechRecognizer.createSpeechRecognizer(this);rec.setRecognitionListener(object:RecognitionListener{
 override fun onReadyForSpeech(p:Bundle?){listening=true;connection.text="● در حال شنیدن"};override fun onBeginningOfSpeech(){};override fun onRmsChanged(v:Float){};override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){listening=false};override fun onError(e:Int){listening=false;connection.text="● آماده";if(continuous)h.postDelayed({listen()},800)}
 override fun onResults(d:Bundle?){listening=false;connection.text="● آماده";val q=d?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty();if(q.isBlank()){if(continuous)h.postDelayed({listen()},700);return};heard.text="شنیدم: $q";if(continuous&&!router.isWake(q)){h.postDelayed({listen()},700);return};handle(router.route(q));if(continuous)h.postDelayed({listen()},1300)}
 override fun onPartialResults(d:Bundle?){d?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let{heard.text="در حال تشخیص: $it"}};override fun onEvent(t:Int,b:Bundle?){}})}
 private fun listen(){if(!::rec.isInitialized||listening||isFinishing)return;try{rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR");putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"fa-IR");putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)})}catch(_:Exception){status.text="میکروفن در دسترس نیست"}}
 private fun handle(c:Command){when(c){Command.Empty->say("بفرمایید");Command.Greet->say("سلام، در خدمتم");Command.Play->say(if(actions.music())"موسیقی را باز کردم" else "برنامه موسیقی پیدا نشد");Command.Stop->say(if(actions.stopMusic())"موسیقی متوقف شد" else "نتوانستم متوقف کنم");is Command.Navigate->say(if(actions.navigate(c.text))"مسیریابی باز شد" else "مقصد را واضح‌تر بگویید");is Command.Call->say(actions.call(c.text));is Command.App->say(if(actions.openApp(c.text))"برنامه را باز کردم" else "برنامه روی دستگاه پیدا نشد");Command.Time->say("الان ساعت ${SimpleDateFormat("HH:mm",Locale("fa","IR")).format(Date())} است.");Command.Weather->say("برای آب و هوای لحظه‌ای، اتصال اینترنت لازم است.");Command.Help->say(help());Command.Goodbye->{continuous=false;store.continuous=false;say("خداحافظ؛ رانندگی ایمن")};is Command.Chat->{ val local=ai.reply(c.text); if(remoteAi.configured()){ Thread { val r=remoteAi.ask(c.text); h.post { say(r ?: local) } }.start() } else say(local) }}}
 private fun help()="می‌توانید بگویید: موسیقی پخش کن، موسیقی را قطع کن، من را به شیراز ببر، به علی زنگ بزن، ساعت چنده، ویز را باز کن، یا سلام ستی."
 private fun say(s:String){status.text=s;if(ready)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"seti")}
 override fun onInit(r:Int){if(r==TextToSpeech.SUCCESS){val z=tts.setLanguage(Locale("fa","IR"));ready=z!=TextToSpeech.LANG_MISSING_DATA&&z!=TextToSpeech.LANG_NOT_SUPPORTED}}
 override fun onDestroy(){h.removeCallbacksAndMessages(null);if(::rec.isInitialized)rec.destroy();if(::tts.isInitialized)tts.shutdown();super.onDestroy()}
}
