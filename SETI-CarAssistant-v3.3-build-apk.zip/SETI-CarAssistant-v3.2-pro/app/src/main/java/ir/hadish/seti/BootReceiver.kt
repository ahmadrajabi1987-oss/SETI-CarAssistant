package ir.hadish.seti
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent?){if(i?.action==Intent.ACTION_BOOT_COMPLETED){c.packageManager.getLaunchIntentForPackage(c.packageName)?.apply{addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(this)}}}}
