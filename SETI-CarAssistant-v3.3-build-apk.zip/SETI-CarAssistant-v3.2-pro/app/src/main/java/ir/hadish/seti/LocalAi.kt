package ir.hadish.seti

import java.util.Locale

/** Local conversational layer. It is intentionally deterministic and offline. */
class LocalAi(private val router: CommandRouter = CommandRouter()) {
    private val history = ArrayDeque<String>()
    private var lastTopic = ""

    fun reply(input: String): String {
        val x = router.normalize(input)
        if (x.isBlank()) return "بفرمایید."
        history.addLast(x); while (history.size > 8) history.removeFirst()
        return when {
            x.contains("اسمت") || x.contains("اسم تو") -> "من SETI هستم؛ دستیار هوشمند صوتی خودرو."
            x.contains("کی هستی") || x.contains("چی هستی") -> "من SETI هستم؛ برای فرمان صوتی، مسیریابی، رسانه و گفت‌وگو طراحی شده‌ام."
            x.contains("چه کار") || x.contains("چه بلدی") -> "می‌توانم موسیقی، مسیریابی، تماس، برنامه‌ها، ساعت و گفت‌وگوی فارسی را مدیریت کنم."
            x.contains("ممنون") || x.contains("مرسی") -> "خواهش می‌کنم."
            x.contains("صبح بخیر") -> "صبح بخیر. آماده‌ام؛ رانندگی ایمن."
            x.contains("شب بخیر") -> "شب بخیر. رانندگی ایمن."
            x.contains("خسته") || x.contains("خوابم میاد") -> "اگر خواب‌آلود هستید، لطفاً در محل امن توقف و استراحت کنید."
            x.contains("دوستت دارم") -> "ممنون. من برای کمک به شما اینجا هستم."
            x.contains("حالت چطوره") || x.contains("خوبی") -> "خوبم و آماده‌ام."
            x.contains("یادت هست") -> if (history.size > 1) "بله، بخشی از گفت‌وگوی همین جلسه را در حافظه موقت دارم." else "هنوز گفت‌وگوی کافی برای یادآوری نداریم."
            x.contains("اسم ماشین") -> "من اطلاعات مدل خودرو را خودکار حدس نمی‌زنم؛ اگر مدل را بگویید می‌توانم در همین جلسه از آن استفاده کنم."
            x.contains("هوا") || x.contains("آب و هوا") -> { lastTopic = "weather"; "برای وضعیت لحظه‌ای هوا به داده آنلاین نیاز دارم." }
            x.contains("چی گوش بدیم") || x.contains("چه آهنگی") -> { lastTopic = "music"; "اگر بخواهید، برنامه موسیقی را باز می‌کنم. چه سبک موسیقی دوست دارید؟" }
            x.contains("الان کجا") -> "برای اعلام موقعیت دقیق، دسترسی موقعیت مکانی لازم است."
            x.startsWith("بله") && lastTopic == "music" -> "باشه؛ موسیقی را آماده می‌کنیم."
            else -> "متوجه شدم: «${input.trim()}». برای پاسخ دانشی کامل، اتصال به یک مدل زبانی واقعی لازم است؛ هسته SETI برای اتصال به آن آماده است."
        }
    }
}
