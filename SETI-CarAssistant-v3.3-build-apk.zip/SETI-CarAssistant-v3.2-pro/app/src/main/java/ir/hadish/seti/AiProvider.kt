package ir.hadish.seti

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import org.json.JSONObject

/** Optional OpenAI-compatible remote AI bridge. Disabled until configured by the user. */
class AiProvider(private val context: Context) {
    private val prefs = context.getSharedPreferences("seti_ai", Context.MODE_PRIVATE)
    fun configured(): Boolean = prefs.getString("url", "").orEmpty().isNotBlank()

    fun setEndpoint(url: String, apiKey: String = "") {
        prefs.edit().putString("url", url.trim()).putString("key", apiKey.trim()).apply()
    }

    fun ask(text: String): String? {
        val endpoint = prefs.getString("url", "").orEmpty()
        if (endpoint.isBlank()) return null
        return try {
            val c = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 6000
                readTimeout = 12000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                prefs.getString("key", "").orEmpty().takeIf { it.isNotBlank() }?.let { setRequestProperty("Authorization", "Bearer $it") }
            }
            val body = JSONObject().apply {
                put("model", "seti")
                put("messages", org.json.JSONArray().put(JSONObject().put("role", "user").put("content", text)))
            }.toString()
            c.outputStream.use { it.write(body.toByteArray(StandardCharsets.UTF_8)) }
            if (c.responseCode !in 200..299) return null
            val raw = c.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(raw)
            json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }
}
