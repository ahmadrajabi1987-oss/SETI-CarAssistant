# ساخت APK برای SETI فقط با گوشی

## روش پیشنهادی: GitHub Actions

1. در GitHub یک حساب بسازید و وارد شوید.
2. یک Repository جدید با نام `SETI-CarAssistant` بسازید.
3. محتوای این پروژه را در Repository آپلود کنید.
4. وارد تب **Actions** شوید.
5. Workflow با نام **Build SETI APK** را انتخاب کنید.
6. روی **Run workflow** بزنید.
7. پس از پایان موفق، در بخش **Artifacts** فایل `SETI-debug-apk` را دانلود کنید.
8. فایل `app-debug.apk` را به مانیتور خودرو منتقل و نصب کنید.

این پروژه Workflow را طوری تنظیم کرده که روی ماشین Build، Java 17، Android SDK 35 و Gradle 8.10.2 آماده شوند و سپس `assembleDebug` اجرا شود.

## روش Codemagic

فایل `codemagic.yaml` نیز در ریشه پروژه قرار دارد. Repository را به Codemagic متصل کنید و Workflow `seti-android-debug` را اجرا کنید. خروجی APK در Artifacts قرار می‌گیرد.

## نکته امنیتی

برای اولین تست از APK debug استفاده کنید. برای نسخه انتشار، باید release signing/keystore تنظیم شود. کلید امضای release را داخل Repository عمومی قرار ندهید.
